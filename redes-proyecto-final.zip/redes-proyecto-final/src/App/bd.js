export const bd = [
    {"nombre": "Tomb Raider", "categoria": "Accion", "edad": "No", "precio": "Q450", "plataforma": "PC", "multijugador": "No"},
    {"nombre": "Fallout 4", "categoria": "Aventura", "edad": "Si", "precio": "Q500", "plataforma": "PC", "multijugador": "Si"},
    {"nombre": "Fortnite", "categoria": "Aventura", "edad": "No", "precio": "Q500", "plataforma": " Xbox", "multijugador": "Si"},
    {"nombre": "Uncharted", "categoria": "Aventura", "edad": "Si", "precio": "Q600", "plataforma": "PlayStation", "multijugador": "Si"},
    {"nombre": "Nier Automata", "categoria": "Aventura", "edad": "Si", "precio": "Q600", "plataforma": "PC", "multijugador": "No"},
    {"nombre": "Call of Duty", "categoria": "Accion", "edad": "Si", "precio": "Q600", "plataforma": "PC", "multijugador": "Si"}
]